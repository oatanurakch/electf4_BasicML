Example for Test package for make circle, then plot circle to display
    from electf4 import tdd
    tdd.tdd_make_circles()

You can use this package work with the result predicted from Tensorflow, if you want to the see example you following: [Example](https://github.com/oatanurakch/electf4_BasicML/blob/master/example.ipynb>).
