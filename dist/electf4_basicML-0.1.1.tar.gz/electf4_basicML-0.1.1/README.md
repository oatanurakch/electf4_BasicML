Example for test Make Circle

.. code-block:: python

    from electf4 import tdd
    
    tdd.tdd_make_circles()
