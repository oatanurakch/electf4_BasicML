Example for test Make Circle

    from electf4 import tdd
    
    tdd.tdd_make_circles()
