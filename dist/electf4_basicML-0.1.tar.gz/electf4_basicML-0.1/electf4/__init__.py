from .make_data import make_circles
from .plot import make_confusion_matrix